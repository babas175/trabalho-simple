package DAO;

import java.sql.Connection;

public interface Conexao {

    static Connection getConnection() {
        return null;
    }

}
