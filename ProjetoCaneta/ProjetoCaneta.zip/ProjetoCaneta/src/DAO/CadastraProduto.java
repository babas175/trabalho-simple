package DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

import model.Produto;
/**
 *
 * @author Bella Line
 */

public class CadastraProduto{
    
    public String salvar(String nome, int id,String descricao, String tamanho , double preco) throws SQLException{
        
           String sql = "INSERT INTO loja VALUES(?,?,?,?,?)";
           
           try{
                 PreparedStatement pstmt = Conexao.getConnection().prepareStatement(sql);
                pstmt.setObject(1, nome);
                pstmt.setObject(2,id);
                pstmt.setObject(3, descricao);
                pstmt.setObject(4, tamanho);
                pstmt.setObject(5, preco);

                pstmt.execute();
                pstmt.close();
                Conexao.getConnection().close();
           }catch(SQLException e){
               throw new SQLException(e.getMessage());
           }
           return "Cadastro realizado com sucesso!";
    }
    
    private boolean buscarPorId(int id) throws SQLException{
        String sql = "SELECT  * FROM loja WHERE id = ?";
        try{
              //System.out.println("Cebolinha");
            PreparedStatement pstmt = Conexao.getConnection().prepareStatement(sql);
            //System.out.println("Depois do statement");
            pstmt.setInt(1, id);
            
            // System.out.println("Antes");
            ResultSet result = pstmt.executeQuery();
          //  System.out.println("Depois");
            
            boolean placaFlag = false;
            if (result.next()) {
               placaFlag = true;
            }
                       
            pstmt.close();
           Conexao.getConnection().close();
           return placaFlag;
      }catch(SQLException e){
          return false;
      }
    }
    
    public String atualizar(String nome, int id,String descricao, String tamanho , double preco) throws SQLException{
        
        
              boolean isExisted = this.buscarPorId(id);
              
              if (!isExisted){
                return "Produto não encontrado!";
              }
              
            String sql = "UPDATE loja SET nome = ?, id = ?, descricao = ?, tamanho = ? , preco =? WHERE id = ?";
           
           try{
                 PreparedStatement pstmt = Conexao.getConnection().prepareStatement(sql);
                pstmt.setObject (1, nome);
                pstmt.setObject(2, id);
                pstmt.setObject(3, descricao);
                pstmt.setObject(4, tamanho);
                pstmt.setObject(4,preco);



                boolean result = pstmt.execute();
                pstmt.close();
                Conexao.getConnection().close();
                if (result) {
                    return "Atualização realizada com sucesso!";
                }
                return "Houve um erro ao atualizar o registro!";
           }catch(SQLException e){
               throw new SQLException(e.getMessage());
           }
    }
    
    public String remover(int id) throws SQLException{
                
              boolean isExisted = this.buscarPorId(id);
              
              if (!isExisted){
                return "Produto não encontrado!";
              }
              
            String sql = "DELETE FROM loja WHERE id = ?";
           
           try{
                 PreparedStatement pstmt = Conexao.getConnection().prepareStatement(sql);
                pstmt.setObject(1, id);

                pstmt.execute();
                pstmt.close();
                Conexao.getConnection().close();
                return "Foi removido com sucesso!";
           }catch(SQLException e){
               throw new SQLException(e.getMessage());
           }
    }
    
}
