package DAO;


import java.sql.SQLException;


import controller.UsuarioController;




public class Usuario extends UsuarioController {

    public void salvar(model.Usuario usuario) throws SQLException {
        String insert = "INSERT INTO loja(nome,cpf,email,telefone,senha) VALUES(?,?,?,?)";
        save(insert, usuario.getNome(),usuario.getCpf(), usuario.getEmail(),usuario.getTelefone(), usuario.getSenha());
    }

    private void save(String insert, String nome, String cpf, String email, int telefone, String senha) {
    }
}