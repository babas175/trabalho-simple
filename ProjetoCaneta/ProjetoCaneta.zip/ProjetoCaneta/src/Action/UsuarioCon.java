package action;

import DAO.Usuario;
import Action.conexao1;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract class UsuarioCon {
    private Connection connection;

    protected UsuarioCon() {
        this.connection = Usuario.getConnection();
    }

    protected Connection getConnection() {
        return connection;
    }

    protected void save(String insertSql, Object... parametros) throws SQLException {
        PreparedStatement pstmt = getConnection().prepareStatement(insertSql);

        for (int i = 0; i < parametros.length; i++) {
            pstmt.setObject(i + 1, parametros[i]);
        }

        pstmt.execute();
        pstmt.close();
        connection.close();
    }
}
