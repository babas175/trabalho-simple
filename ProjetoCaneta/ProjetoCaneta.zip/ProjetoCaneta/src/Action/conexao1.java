package Action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexao1 {
    private static final String URL_MYSQL = "jdbc:mysql://localhost/loja";
    private static final String USER = "seu_usuario";
    private static final String PASS = "sua_senha";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(URL_MYSQL, USER, PASS);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver JDBC não encontrado", e);
        }
    }
}
