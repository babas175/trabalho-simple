package controller;


import model.Usuario;
/**
 *
 * @author Bella Line
 */
public class UsuarioController {
    public void salvar(String nome,String cpf,int telefone,String email,String senha){
        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setCpf(cpf);
        usuario.setEmail(email);     
        usuario.setTelefone(telefone);
        usuario.setSenha(senha);
        
    }
    
}
