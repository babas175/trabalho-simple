/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import model.Produto;
/**
 *
 * @author Bella Line
 */
public class ProdutoController {
    public void salvar(String nome,int id,String descricao,String tamanho,double preco){
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setDescricao(descricao);
        produto.setId(id);
        produto.setTamanho(tamanho);
        produto.setPreco(preco);
        
    }
}
